# Bharat Warriors – Static Site

This repository contains a single-page static website for the Bharat Warriors Cricket Club.

## How to publish on GitHub Pages
1. Create a new **public** repo (e.g., `bharat-warriors`).
2. Upload these files to the repo root:
   - `index.html`
   - `bharat-warriors-logo.png`
   - `favicon.png`
3. Go to **Settings → Pages** → set **Source: Deploy from a branch**, **Branch: main**, **Folder: /(root)** → **Save**.
4. Your site will appear at `https://<your-username>.github.io/bharat-warriors/`.

## Editing
- Update fixtures in the `<tbody>` of the table.
- Update the squad by editing the player cards.
- Replace Unsplash images with your own photos.
- Contact form currently uses `mailto:` (no backend).

Har Har Mahadev!
